import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid, TextField } from '@mui/material';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

export default function ModalAddProspect(props) {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [name, setName] = useState(null)
  const [searchkey, setSearchKey] = useState(null)
  const [edad, setEdad] = useState(null)
  const [puesto, setPuesto] = useState(null)
  const [pais, setPais] = useState(null)
  const [EstadoDeseado, setEstadoDeseado] = useState(null)

  const handleName = (event) => {
    setName(event.target.value)
  }

  const handlesearchkey = (event) => {
    setSearchKey(event.target.value)
  }

  const handleEdad = (event) => {
    setEdad(event.target.value)
  }

  const handlePuesto = (event) => {
    setPuesto(event.target.value)
  }

  const handlePais = (event) => {
    setPais(event.target.value)
  }

  const handleEstado = (event) => {
    setEstadoDeseado(event.target.value)
  }

  const createProspect = () => {
    let newProspect = {
        nombre: name,
        searchkey: searchkey,
        edad: parseInt(edad), 
        puesto: puesto,
        pais, pais,
        estadoDeseado: EstadoDeseado
    }
    console.log(newProspect)
    let currentProspects = [...props.prospects]
    currentProspects.push(newProspect)
    props.setProspects(currentProspects)
    setOpen(false)
  }

  return (
    <div>
      <Button onClick={handleOpen}>Agregar Candidato</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
            <Grid container>
             <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Nombre: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handleName} size='small'/>
          </Grid>
          <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
          searchkey: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handlesearchkey} size='small'/>
          </Grid>
          <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
          Edad: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handleEdad} size='small'/>
          </Grid>
          <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
          Puesto: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handlePuesto} size='small'/>
          </Grid>
          <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
          Pais: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handlePais} size='small'/>
          </Grid>
          <Grid item xs={6}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
          Estado Deseado: 
          </Typography>
          </Grid>

          <Grid item xs={6}>
           <TextField onChange={handleEstado} size='small'/>
          </Grid>
          </Grid>
          <Button onClick={()=> createProspect()}>Guardar</Button>
        </Box>
      </Modal>
    </div>
  );
}
