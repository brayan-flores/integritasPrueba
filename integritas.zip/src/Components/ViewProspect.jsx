import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';

export default function ViewProspect(props) {

    const [propspects, setProspects] = React.useState([])

    console.log(propspects)

    React.useEffect(()=> {
        setProspects(props.prospects)
    }, [props])

  return (
    <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
             {
                   propspects.map((item) => (
                    <>
      <ListItem alignItems="flex-start">
        <ListItemAvatar>
          <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
        </ListItemAvatar>
        <ListItemText
          secondary={
            <React.Fragment>

                
              <Typography
                sx={{ display: 'inline' }}
                component="span"
                variant="body2"
                color="text.primary"
              >
                <List>
                    Nombre : {item.nombre}
                    </List>
                    <List>
                    searchkey : {item.searchkey}
                    </List>
                    <List>
                    edad : {item.edad}
                    </List>
                    <List>
                    puesto : {item.puesto}
                    </List>
                    <List>
                    pais : {item.pais}
                    </List>
                    <List>
                    Estado Deseado : {item.estadoDeseado}
                    </List>
              </Typography>
            
            </React.Fragment>
          }
        />
      </ListItem>
      <Divider />
      <Divider variant="inset" component="li" />
      </>
      ))
    }
    
    </List>
  );
}
