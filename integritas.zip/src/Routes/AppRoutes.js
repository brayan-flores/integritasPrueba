import React, { Fragment } from "react";
import {
    BrowserRouter as Router,
    Route,
    BrowserRouter,
    Routes,
  } from "react-router-dom";
import IntegritasHome from "../Pages/IntegritasHome";
import AddProspect from "../Pages/AddProspect";

const AppRoutes = () => {
    return(
        <Fragment>

        <BrowserRouter>
           <Routes>
           <Route path="/" element={<IntegritasHome />} />
           <Route path="/AddProspect" element={<AddProspect />} />
           </Routes>
        </BrowserRouter>

        </Fragment>
    )
}

export default AppRoutes;