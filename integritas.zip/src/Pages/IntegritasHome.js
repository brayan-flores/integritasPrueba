import React, { Fragment, useEffect, useState } from "react";


const IntegritasHome = () => {

    const [sortedData, setSortedData] = useState([])

    useEffect(()=> {
        setSortedData(orderRegisters)
        console.log(orderRegisters)
    }, [])

    const DataDummy = [
        {
            nombre: 'Brayan Flores',
            searchkey: 'brayanflo',
            edad: 25,
            puesto: 'Desarrollador',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'Jesus Perez',
            searchkey: 'jesus',
            edad: 30,
            puesto: 'Desarrollador',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'James Webb',
            searchkey: 'jameswebb',
            edad: 70,
            puesto: 'UX',
            pais: 'EUA',
            estadoDeseado: 'NewYork'
        },
        {
            nombre: 'Alan Perez',
            searchkey: 'alan',
            edad: 22,
            puesto: 'UX',
            pais: 'Mexico',
            estadoDeseado: 'Guadalajara'
        },
        {
            nombre: 'Raul Perez',
            searchkey: 'raul',
            edad: 38,
            puesto: 'Desarrollador',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'Ricardo Perez',
            searchkey: 'ricardo',
            edad: 17,
            puesto: 'Estudiante',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'Ricardo Perez',
            searchkey: 'ricardoPerez',
            edad: 45,
            puesto: 'RH',
            pais: 'Colombia',
            estadoDeseado: 'Bogota'
        },
        {
            nombre: 'Adrian Perez',
            searchkey: 'adrian',
            edad: 32,
            puesto: 'Desarrollador',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'Miguel Perez',
            searchkey: 'miguel',
            edad: 55,
            puesto: 'UX',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        },
        {
            nombre: 'Luis Perez',
            searchkey: 'juanperez',
            edad: 39,
            puesto: 'Desarrollador',
            pais: 'Mexico',
            estadoDeseado: 'CDMX'
        }
    ]

    const orderRegisters = DataDummy.sort((a, b) => {
        // Ordenar por nombre de forma descendente
        if (a.nombre < b.nombre) return 1;
        if (a.nombre > b.nombre) return -1;
        
        // Si los nombres son iguales, ordenar por edad de forma ascendente
        if (a.edad < b.edad) return -1;
        if (a.edad > b.edad) return 1;
        return 0;
      });

    return(
        <Fragment>

            {
                sortedData.map((item) => (
                    <div>
                    <p>Nombre : {item.nombre}</p>
                    <p>searchkey : {item.searchkey}</p>
                    <p>edad : {item.edad}</p>
                    <p>puesto : {item.puesto}</p>
                    <p>pais : {item.pais}</p>
                    <p>estadoDeseado : {item.estadoDeseado}</p>
                    <hr />
                    </div>
                ))
            }

        </Fragment>
    )
}

export default IntegritasHome;