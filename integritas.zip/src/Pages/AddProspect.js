import { Button, Grid, TextField } from "@mui/material";
import React, { Fragment, useEffect, useState } from "react";
import ViewProspect from "../Components/ViewProspect";
import ModalAddProspect from "../Components/ModalAddProspect";

const AddProspect = () => {

    const [prospects, setProspects] = useState([])
    const [alert, setAlert] = useState(false)

    console.log(prospects)

    useEffect(()=> {

    }, [prospects])

    const handleSearch = (event) => {
        buscarCoincidencias(event.target.value, prospects)
    }

function buscarCoincidencias(descripcion, prospects) {
    const partesDescripcion = descripcion.split(' ');
    const puesto = partesDescripcion[1];
    const edadMinima = parseInt(partesDescripcion[2].split('-')[0]);
    const edadMaxima = parseInt(partesDescripcion[2].split('-')[1]);
    const estado = partesDescripcion[4];
    console.log('puesto', puesto)
    const coincidencias = prospects.filter(registro => registro.puesto === puesto || registro.edad >= edadMinima || registro.edad <= edadMaxima || registro.estadoDeseado === estado);
    if (coincidencias.length > 0) {
      console.log('Coincidencias encontradas:');
      console.log(coincidencias);
      setProspects(coincidencias)
      setAlert(false)
      return coincidencias;
    } else {
      console.log('No se encontraron coincidencias');
      setAlert('No se encontraron coincidencias')
      return [];
    }
  }
  
//   buscarCoincidencias('Solicito Desarrollador 29 - 30 años en CDMX', prospects);
  

    return(
        <Fragment>

        <div style={{marginTop: '4%', marginLeft: '10%'}}>
            <Grid container>
                <Grid item xs={2}>
                 <ModalAddProspect prospects={prospects} setProspects={setProspects} />
                </Grid>
                <Grid item xs={2}>
                <TextField onChange={handleSearch} placeholder="Buscar Candidato" />
                </Grid>
            </Grid>

            

            {
                alert ? <p>{alert}</p> : 
                
                    prospects.length > 0 ? (
                       <ViewProspect prospects={prospects} />
                    ) : <p>no hay candidatos registrados</p>
            }

        </div>

        </Fragment>
    )
}

export default AddProspect;